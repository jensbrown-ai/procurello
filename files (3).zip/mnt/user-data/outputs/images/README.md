# Product images

This folder holds product images used by `catalog-guided-buying.html`.

## Required files

| Filename | Product | Source URL |
|---|---|---|
| `microflex.png` | Microflex MidKnight Nitrile Exam Gloves | https://www.mimilk.com/wp-content/uploads/2023/02/5038.5043.5044.5045.5046.5049midknight.png |
| `vwr.jpg` | VWR Signature Nitrile Exam | https://www.cliawaived.com/media/catalog/product/cache/9d02d92ddd22ed701b82526ad1ff3948/v/w/vwr-82026_1_1.jpg |
| `ansell.png` | Ansell TouchNTuff Nitrile | https://industrialsafety.com/media/catalog/product/cache/99dc5e1dc90eb9727970ba1a904a05a5/t/o/touchntuff_92-600_boxonly.ashx.png |

## Quick setup

**Option 1 — Run the script (Mac/Linux/WSL):**
```bash
bash images/download-images.sh
```

**Option 2 — Download manually:**
Open each URL in a browser, save the image to this folder with the matching filename above.

**Option 3 — PowerShell (Windows):**
```powershell
cd images
iwr -o microflex.png "https://www.mimilk.com/wp-content/uploads/2023/02/5038.5043.5044.5045.5046.5049midknight.png"
iwr -o vwr.jpg "https://www.cliawaived.com/media/catalog/product/cache/9d02d92ddd22ed701b82526ad1ff3948/v/w/vwr-82026_1_1.jpg"
iwr -o ansell.png "https://industrialsafety.com/media/catalog/product/cache/99dc5e1dc90eb9727970ba1a904a05a5/t/o/touchntuff_92-600_boxonly.ashx.png"
```

## If a URL stops working

These are third-party hosted images and may eventually move or be blocked by hotlinking rules. If a download fails, search for the product name + "nitrile gloves" and substitute any reasonable product photo at the same filename.

## Notes

- Images are styled with `object-fit: contain` in the page CSS, so they'll letterbox to fit the 80px-tall product card slots regardless of native dimensions.
- Filenames are lowercase to avoid case-sensitivity issues on hosted Linux servers (Netlify, GitHub Pages, Vercel).
- File extensions matter — keep `.png` for microflex/ansell and `.jpg` for vwr to match the HTML references.
